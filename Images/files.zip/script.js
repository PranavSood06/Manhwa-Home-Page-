// ==========================================
// EXPERIMENT 3 - Job Search Form
// Show user profile without page reload
// ==========================================

function showProfile() {

    // Step 1: Get values from the form
    var name = document.getElementById("fullName").value;
    var email = document.getElementById("email").value;
    var exp = document.getElementById("experience").value;
    var role = document.getElementById("role").value;
    var location = document.getElementById("location").value;
    var skills = document.getElementById("skills").value;

    // Step 2: Simple validation
    if (name == "") {
        alert("Please enter your name!");
        return;
    }
    if (email == "") {
        alert("Please enter your email!");
        return;
    }

    // Step 3: Put the values into the profile section
    document.getElementById("profileName").innerText = name;
    document.getElementById("profileEmail").innerText = email;
    document.getElementById("profileExp").innerText = exp + " Years";
    document.getElementById("profileRole").innerText = role;
    document.getElementById("profileLocation").innerText = location;
    document.getElementById("profileSkills").innerText = skills;

    // Step 4: Show the profile box (it was hidden before)
    document.getElementById("profileBox").style.display = "block";
}


// ==========================================
// EXPERIMENT 4 - Job Posting Form
// Add job cards dynamically on the page
// ==========================================

function postJob() {

    // Step 1: Get values from the job form
    var title = document.getElementById("jobTitle").value;
    var company = document.getElementById("companyName").value;
    var location = document.getElementById("jobLocation").value;
    var type = document.getElementById("jobType").value;
    var salary = document.getElementById("salary").value;
    var desc = document.getElementById("jobDesc").value;

    // Step 2: Simple validation
    if (title == "") {
        alert("Please enter a job title!");
        return;
    }
    if (company == "") {
        alert("Please enter a company name!");
        return;
    }

    // Step 3: Create a new div (this will be the job card)
    var card = document.createElement("div");
    card.className = "job-card";

    // Step 4: Put content inside the card using innerHTML
    card.innerHTML =
        "<h3>" + title + "</h3>" +
        "<p><b>Company:</b> " + company + "</p>" +
        "<p><b>Location:</b> " + location + "</p>" +
        "<p><b>Job Type:</b> " + type + "</p>" +
        "<p><b>Salary:</b> " + salary + "</p>" +
        "<p><b>Description:</b> " + desc + "</p>" +
        "<button onclick='this.parentElement.remove()'>Delete</button>";

    // Step 5: Add the card to the job cards section on the page
    document.getElementById("jobCardsSection").appendChild(card);

    // Step 6: Clear the form after submitting
    document.getElementById("jobTitle").value = "";
    document.getElementById("companyName").value = "";
    document.getElementById("jobLocation").value = "";
    document.getElementById("jobType").value = "";
    document.getElementById("salary").value = "";
    document.getElementById("jobDesc").value = "";

    alert("Job posted successfully!");
}
